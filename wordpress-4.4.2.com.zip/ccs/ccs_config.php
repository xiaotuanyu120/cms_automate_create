<?php

//接口类型
$ccs_site_type = 'wordpress';

//引入网站系统数据库配置文件(这个地方也可以手动配置)
include_once('../wp-config.php');

$db_host	   = DB_HOST;			//数据库主机,如果是端口不是3306，那么就是localhost:Port 例：localhost:3307
$db_name	   = DB_NAME;			//数据库名
$db_user	   = DB_USER;			//用户名
$db_pwd		   = DB_PASSWORD;			  //密码
$db_tablepre = $table_prefix;	  //数据库表前缀
$db_charset  = 'utf8';  			//字符集（默认gbk），经过测试，不管什么编码都放utf8，基本不用修改

?>