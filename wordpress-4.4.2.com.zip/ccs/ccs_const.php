<?php
	$password   = '<wordpress-123>';   //如果想用固定密码，请修改这里
	
	$charpath   = '<charpath>';   //文字转图片保存路径，相对路径
	
	$attachpath = '<attachpath>'; //附件存放路径，相对路径
	
	$verifycode = "<verifycode>"; //验证码，验证数据来源合法性
?>