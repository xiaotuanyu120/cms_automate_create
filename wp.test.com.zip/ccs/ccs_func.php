<?php   

//...标明是接口调用
$firstpage ='ccs';

//数据库相关函数***************************************************************
//...1、数据库连接函数
function db_connect($dbhost , $dbname, $dbuser, $dbpw, $dbcharset)
{
	//a、连接服务器
	$con = mysql_connect($dbhost, $dbuser, $dbpw);
	if (!$con) 
	{
		return '<___code___>901</___code___><desc>服务器连接失败: ' . mysql_error().'</desc>';
	}
	
	//b、选择数据库
	$db_selected = mysql_select_db($dbname);
	if (!$db_selected)
	{
		return '<___code___>901</___code___><desc>数据库连接失败:'.mysql_error().'</desc>';
	}
	
	//c、设置字符集
	mysql_query("SET character_set_connection=".$dbcharset.", character_set_results=".$dbcharset.", character_set_client=binary", $con);
	
	return $con;
}

//...2、关闭数据库(该函数一般来说不需要 )
function db_close()
{
	mysql_close();
}

//...3、获取查询到的第一个数据
function db_first_value($sql)
{
	$result = mysql_query($sql);
	if (!$result) 
    {
        $message  = 'Invalid query: ' . mysql_error() . "\n";
        $message .= 'Whole query: ' . $sql;
        exit("<___code___>999</___code___><desc>$message</desc>");
	}
	
	$data = mysql_fetch_array($result);	
	return $data[0];
}

//...4、获取当前行的数据
function db_first_line($sql)
{
	$result = mysql_query($sql);
	if (!$result) 
    {
        $message  = 'Invalid query: ' . mysql_error() . "\n";
        $message .= 'Whole query: ' . $sql;
        exit("<___code___>999</___code___><desc>$message</desc>");
	}
	
	$data = mysql_fetch_array($result);	
	
	return $data;		
}

//...5、最后插入语句的返回ID
function db_insert_id($sql) 
{	
	$result = mysql_query($sql);
	if (!$result) 
    {
        $message  = 'Invalid query: ' . mysql_error() . "\n";
        $message .= 'Whole query: ' . $sql;
        exit("<___code___>999</___code___><desc>$message</desc>");
	}
	return mysql_insert_id();
}

//...6、执行sql语句
function db_query($sql)
{
	$result = mysql_query($sql);
	if (!$result) 
    {
        $message  = 'Invalid query: ' . mysql_error() . "\n";
        $message .= 'Whole query: ' . $sql;
        exit("<___code___>999</___code___><desc>$message</desc>");
	}
	return $result;
}

//...执行SQL语句，返回值转换成xml格式
function db_execsql_as_xml($sql,$tpre)
{		
	$sql = stripslashes($sql);//不让传入的值转义
	$sql = str_ireplace('[tablepre]',$tpre,$sql); 
	$result = mysql_query($sql);
	$sLine = "";
	$RetHeader = "";
	$RetData   = "";
	if (!$result)
	{
		exit('<___code___>901</___code___><desc>'.mysql_error().'</desc>');
	}
	else
	{
		if ($result == 1)
		{
			exit('<___code___>0</___code___><desc></desc>');
		}
		else
		{				
			//1、生成字段相关信息数组 name type size
			$field_count = mysql_num_fields($result);
			for ($i=0; $i<$field_count; $i++)
			{
  				$names[$i] = mysql_field_name($result, $i);
  				$types[$i] = mysql_field_type($result, $i);
  				$sizes[$i] = mysql_field_len($result , $i);  				
  				
  				if(($types[$i]=="blob") || ($types[$i]=="unknown"))
  				{
  					$types[$i] ="blob";
  					$sizes[$i] = 0;
  				}  				
			}			
			
			//2、循环获取数据体 双重循环 blob类型字段，实时判断字段长度
			$sLen = 0;
			while ($info = mysql_fetch_array( $result, MYSQL_ASSOC ))
			{
				$sLine="";
				$i = 0;
				while (list($key, $val) = each($info)) 
				{
					if($types[$i]=="blob")
					{
						//$val = trim($val);
						$sLen = strlen($val);
						if($sLen>$sizes[$i]) $sizes[$i] = $sLen;						
					}
										
					$sLine = $sLine."<$key>$val</$key>";					
					$i++;
				}
				$RetData = $RetData."<__item__>$sLine</__item__>".chr(13).chr(10);
			}
			
			//3、生成数据表头 
			for ($i=0; $i<$field_count; $i++)
			{  				 				
  				if(($types[$i]=='blob')) $types[$i] = 'string';  				
  				$RetHeader = $RetHeader."<name>$names[$i]</name><type>$types[$i]</type><size>$sizes[$i]</size>".chr(13).chr(10);
			}
			$RetHeader = "<header>$RetHeader</header>";
			
			echo("<___code___>0</___code___><desc>".chr(13).chr(10).$RetHeader.chr(13).chr(10).$RetData.chr(13).chr(10)."</desc>");									
		}
	}
}
//***************************************************************数据库相关函数


//*********字符串函数***************************************************************
//...1、生成随机字符串
function str_random($length) {
	$hash = '';
	$chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz';
	$max = strlen($chars) - 1;
	PHP_VERSION < '4.2.0' && mt_srand((double)microtime() * 1000000);
	for($i = 0; $i < $length; $i++) {
		$hash .= $chars[mt_rand(0, $max)];
	}
	return strtolower($hash);
}

  //php版本 FieldValueByName() 函数
function FieldValueByName($str_, $Name_)
{
	$str = strtolower($str_);
	$Name = strtolower($Name_);

	$start=strpos($str, "<" . $Name . ">");
	$end=strpos($str, "</" . $Name . ">");
	
	if ($start>=0 && $end>=0 &&$end>$start)
	{				
		$start = $start+strlen($Name)+2;
		$result = substr($str_, $start, $end-$start);
	}else
	{
		$result = "";	
	}
	
	return $result;
}

//------------------------------------------------------------------------------
//2009-08-11 11:25 LHM FieldValue():PHP版本
//2011-07-07 23:25 HST 集成到本单元
function FieldValue($strsplit,$str,$ifield)
{   
    $strarray=array();
    if(strlen($str) > 0 && strlen($strsplit)>0)
    {   
        if(strstr($str,$strsplit))
        {   
           $strarray=explode($strsplit,$str);
           if($ifield >= 0)
           {
              if(count($strarray) >= $ifield)
               {
                   return $strarray[$ifield];
               }
              else
               {         
                 //echo "越界啦";
                 return "";
               }
           }
           else
           {
               //echo "ifield不能小于0";
               return "";
           }
        }        
        else
        {
            $strarray[0]=$str;
            return $strarray[0];            
        }
    }
        
    else
    {
    	//echo "确认输入是否为字符串";
    	return "";
    }            
}

//Xml转数组, 包括根键 
function xml_to_array( $xml )
{
	$reg = "/<(\w+)[^>]*>([\\x00-\\xFF]*)<\\/\\1>/";
	if(preg_match_all($reg, $xml, $matches))
	{
		$count = count($matches[0]);
		for($i = 0; $i < $count; $i++)
		{
			$subxml = $matches[2][$i];
			$key = $matches[1][$i];
			if(preg_match( $reg, $subxml ))
			{
				$arr[$key] = xml_to_array( $subxml );
			}
			else
			{
				$arr[$key] = $subxml;
			}
		}
	}
	return $arr;
}

//Xml转数组, 不包括根键 
function xmltoarray( $xml ) 
{ 
	$arr = xml_to_array($xml); 
	$key = array_keys($arr); 
	return $arr[$key[0]]; 
} 

//汉字转为拼音（全/简拼）

$d=array(
array("a",-20319),
array("ai",-20317),
array("an",-20304),
array("ang",-20295),
array("ao",-20292),
array("ba",-20283),
array("bai",-20265),
array("ban",-20257),
array("bang",-20242),
array("bao",-20230),
array("bei",-20051),
array("ben",-20036),
array("beng",-20032),
array("bi",-20026),
array("bian",-20002),
array("biao",-19990),
array("bie",-19986),
array("bin",-19982),
array("bing",-19976),
array("bo",-19805),
array("bu",-19784),
array("ca",-19775),
array("cai",-19774),
array("can",-19763),
array("cang",-19756),
array("cao",-19751),
array("ce",-19746),
array("ceng",-19741),
array("cha",-19739),
array("chai",-19728),
array("chan",-19725),
array("chang",-19715),
array("chao",-19540),
array("che",-19531),
array("chen",-19525),
array("cheng",-19515),
array("chi",-19500),
array("chong",-19484),
array("chou",-19479),
array("chu",-19467),
array("chuai",-19289),
array("chuan",-19288),
array("chuang",-19281),
array("chui",-19275),
array("chun",-19270),
array("chuo",-19263),
array("ci",-19261),
array("cong",-19249),
array("cou",-19243),
array("cu",-19242),
array("cuan",-19238),
array("cui",-19235),
array("cun",-19227),
array("cuo",-19224),
array("da",-19218),
array("dai",-19212),
array("dan",-19038),
array("dang",-19023),
array("dao",-19018),
array("de",-19006),
array("deng",-19003),
array("di",-18996),
array("dian",-18977),
array("diao",-18961),
array("die",-18952),
array("ding",-18783),
array("diu",-18774),
array("dong",-18773),
array("dou",-18763),
array("du",-18756),
array("duan",-18741),
array("dui",-18735),
array("dun",-18731),
array("duo",-18722),
array("e",-18710),
array("en",-18697),
array("er",-18696),
array("fa",-18526),
array("fan",-18518),
array("fang",-18501),
array("fei",-18490),
array("fen",-18478),
array("feng",-18463),
array("fo",-18448),
array("fou",-18447),
array("fu",-18446),
array("ga",-18239),
array("gai",-18237),
array("gan",-18231),
array("gang",-18220),
array("gao",-18211),
array("ge",-18201),
array("gei",-18184),
array("gen",-18183),
array("geng",-18181),
array("gong",-18012),
array("gou",-17997),
array("gu",-17988),
array("gua",-17970),
array("guai",-17964),
array("guan",-17961),
array("guang",-17950),
array("gui",-17947),
array("gun",-17931),
array("guo",-17928),
array("ha",-17922),
array("hai",-17759),
array("han",-17752),
array("hang",-17733),
array("hao",-17730),
array("he",-17721),
array("hei",-17703),
array("hen",-17701),
array("heng",-17697),
array("hong",-17692),
array("hou",-17683),
array("hu",-17676),
array("hua",-17496),
array("huai",-17487),
array("huan",-17482),
array("huang",-17468),
array("hui",-17454),
array("hun",-17433),
array("huo",-17427),
array("ji",-17417),
array("jia",-17202),
array("jian",-17185),
array("jiang",-16983),
array("jiao",-16970),
array("jie",-16942),
array("jin",-16915),
array("jing",-16733),
array("jiong",-16708),
array("jiu",-16706),
array("ju",-16689),
array("juan",-16664),
array("jue",-16657),
array("jun",-16647),
array("ka",-16474),
array("kai",-16470),
array("kan",-16465),
array("kang",-16459),
array("kao",-16452),
array("ke",-16448),
array("ken",-16433),
array("keng",-16429),
array("kong",-16427),
array("kou",-16423),
array("ku",-16419),
array("kua",-16412),
array("kuai",-16407),
array("kuan",-16403),
array("kuang",-16401),
array("kui",-16393),
array("kun",-16220),
array("kuo",-16216),
array("la",-16212),
array("lai",-16205),
array("lan",-16202),
array("lang",-16187),
array("lao",-16180),
array("le",-16171),
array("lei",-16169),
array("leng",-16158),
array("li",-16155),
array("lia",-15959),
array("lian",-15958),
array("liang",-15944),
array("liao",-15933),
array("lie",-15920),
array("lin",-15915),
array("ling",-15903),
array("liu",-15889),
array("long",-15878),
array("lou",-15707),
array("lu",-15701),
array("lv",-15681),
array("luan",-15667),
array("lue",-15661),
array("lun",-15659),
array("luo",-15652),
array("ma",-15640),
array("mai",-15631),
array("man",-15625),
array("mang",-15454),
array("mao",-15448),
array("me",-15436),
array("mei",-15435),
array("men",-15419),
array("meng",-15416),
array("mi",-15408),
array("mian",-15394),
array("miao",-15385),
array("mie",-15377),
array("min",-15375),
array("ming",-15369),
array("miu",-15363),
array("mo",-15362),
array("mou",-15183),
array("mu",-15180),
array("na",-15165),
array("nai",-15158),
array("nan",-15153),
array("nang",-15150),
array("nao",-15149),
array("ne",-15144),
array("nei",-15143),
array("nen",-15141),
array("neng",-15140),
array("ni",-15139),
array("nian",-15128),
array("niang",-15121),
array("niao",-15119),
array("nie",-15117),
array("nin",-15110),
array("ning",-15109),
array("niu",-14941),
array("nong",-14937),
array("nu",-14933),
array("nv",-14930),
array("nuan",-14929),
array("nue",-14928),
array("nuo",-14926),
array("o",-14922),
array("ou",-14921),
array("pa",-14914),
array("pai",-14908),
array("pan",-14902),
array("pang",-14894),
array("pao",-14889),
array("pei",-14882),
array("pen",-14873),
array("peng",-14871),
array("pi",-14857),
array("pian",-14678),
array("piao",-14674),
array("pie",-14670),
array("pin",-14668),
array("ping",-14663),
array("po",-14654),
array("pu",-14645),
array("qi",-14630),
array("qia",-14594),
array("qian",-14429),
array("qiang",-14407),
array("qiao",-14399),
array("qie",-14384),
array("qin",-14379),
array("qing",-14368),
array("qiong",-14355),
array("qiu",-14353),
array("qu",-14345),
array("quan",-14170),
array("que",-14159),
array("qun",-14151),
array("ran",-14149),
array("rang",-14145),
array("rao",-14140),
array("re",-14137),
array("ren",-14135),
array("reng",-14125),
array("ri",-14123),
array("rong",-14122),
array("rou",-14112),
array("ru",-14109),
array("ruan",-14099),
array("rui",-14097),
array("run",-14094),
array("ruo",-14092),
array("sa",-14090),
array("sai",-14087),
array("san",-14083),
array("sang",-13917),
array("sao",-13914),
array("se",-13910),
array("sen",-13907),
array("seng",-13906),
array("sha",-13905),
array("shai",-13896),
array("shan",-13894),
array("shang",-13878),
array("shao",-13870),
array("she",-13859),
array("shen",-13847),
array("sheng",-13831),
array("shi",-13658),
array("shou",-13611),
array("shu",-13601),
array("shua",-13406),
array("shuai",-13404),
array("shuan",-13400),
array("shuang",-13398),
array("shui",-13395),
array("shun",-13391),
array("shuo",-13387),
array("si",-13383),
array("song",-13367),
array("sou",-13359),
array("su",-13356),
array("suan",-13343),
array("sui",-13340),
array("sun",-13329),
array("suo",-13326),
array("ta",-13318),
array("tai",-13147),
array("tan",-13138),
array("tang",-13120),
array("tao",-13107),
array("te",-13096),
array("teng",-13095),
array("ti",-13091),
array("tian",-13076),
array("tiao",-13068),
array("tie",-13063),
array("ting",-13060),
array("tong",-12888),
array("tou",-12875),
array("tu",-12871),
array("tuan",-12860),
array("tui",-12858),
array("tun",-12852),
array("tuo",-12849),
array("wa",-12838),
array("wai",-12831),
array("wan",-12829),
array("wang",-12812),
array("wei",-12802),
array("wen",-12607),
array("weng",-12597),
array("wo",-12594),
array("wu",-12585),
array("xi",-12556),
array("xia",-12359),
array("xian",-12346),
array("xiang",-12320),
array("xiao",-12300),
array("xie",-12120),
array("xin",-12099),
array("xing",-12089),
array("xiong",-12074),
array("xiu",-12067),
array("xu",-12058),
array("xuan",-12039),
array("xue",-11867),
array("xun",-11861),
array("ya",-11847),
array("yan",-11831),
array("yang",-11798),
array("yao",-11781),
array("ye",-11604),
array("yi",-11589),
array("yin",-11536),
array("ying",-11358),
array("yo",-11340),
array("yong",-11339),
array("you",-11324),
array("yu",-11303),
array("yuan",-11097),
array("yue",-11077),
array("yun",-11067),
array("za",-11055),
array("zai",-11052),
array("zan",-11045),
array("zang",-11041),
array("zao",-11038),
array("ze",-11024),
array("zei",-11020),
array("zen",-11019),
array("zeng",-11018),
array("zha",-11014),
array("zhai",-10838),
array("zhan",-10832),
array("zhang",-10815),
array("zhao",-10800),
array("zhe",-10790),
array("zhen",-10780),
array("zheng",-10764),
array("zhi",-10587),
array("zhong",-10544),
array("zhou",-10533),
array("zhu",-10519),
array("zhua",-10331),
array("zhuai",-10329),
array("zhuan",-10328),
array("zhuang",-10322),
array("zhui",-10315),
array("zhun",-10309),
array("zhuo",-10307),
array("zi",-10296),
array("zong",-10281),
array("zou",-10274),
array("zu",-10270),
array("zuan",-10262),
array("zui",-10260),
array("zun",-10256),
array("zuo",-10254)
);
function g($num)
{
 global $d;
 if($num>0&&$num<160)
 {
  return chr($num);
 }
 elseif($num<-20319||$num>-10247)
 {
  return "";
 }else{
  for($i=count($d)-1;$i>=0;$i--)
  {
   if($d[$i][1]<=$num)
    break;
  }
  return $d[$i][0];
 }
}
function fullc($str)
{
 $ret="";
 for($i=0;$i<strlen($str);$i++)
 {
  $p=ord(substr($str,$i,1));
  if($p>160)
  {
   $q=ord(substr($str,++$i,1));
   $p=$p*256+$q-65536;
  }
  $ret.=g($p);
 }
 return $ret;
}
function firstc($str)
{
 $ret="";
 for($i=0;$i<strlen($str);$i++)
 {
  $p=ord(substr($str,$i,1));
  if($p>160)
  {
   $q=ord(substr($str,++$i,1));
   $p=$p*256+$q-65536;
  }
  $ret.=substr(g($p), 0, 1);
 }
 return $ret;
}


function str_random_email()
{
	$emails = array("@gmail.com","@yahoo.com","@msn.com","@hotmail.com","@aol.com","@ask.com","@live.com","@qq.com","@0355.net","@163.com","@163.net","@263.net","@3721.net","@yeah.net","@googlemail.com","@mail.com","@hotmail.com","@msn.com","@yahoo.com","@gmail.com","@aim.com","@aol.com","@mail.com","@walla.com","@inbox.com","@126.com","@163.com","@sina.com","@21cn.com","@sohu.com","@yahoo.com.cn","@tom.com","@qq.com","@etang.com","@eyou.com","@56.com","@chinaren.com","@sogou.com","@citiz.com");
	return $emails[mt_rand(0,count($emails))-1];
}

//...获取中国IP段的随即IP
function str_china_ip()
{
	$chinaip = array("973996032-786431","975044608-2228223","977403904-131071","978452480-131071","978796544-16383",
        "979632128-131071","980680704-262143","981467136-524287","982515712-65535","985661440-393215",
        "986185728-1572863","988807168-1048575","991952896-3407871","996868096-196607","999751680-32767",
        "1002373120-32767","1002438656-5062655","1007517696-1212415","1010237440-65535","1010761728-65535",
        "1017118720-2097151","1019346944-131071","1019740160-327679","1020264448-1048575","1021837312-131071",
        "1023344640-65535","1024335184-15","1025245184-32767","1025343488-32767","1026392064-16383","1026523136-16383",
        "1026555904-524287","1031798784-2184003","1033982789-18418","1034001216-1991871","1038614528-393215",
        "1039138816-262143","1050616656-15","1067617792-255","1076029952-255","1358900672-63","2030305280-131071",
        "2030567424-1441791","2032140288-327679","2032664576-262143","2080784384-16383","2081423360-131071",
        "2081685504-131071","2082275328-32767","2083028992-16383","2083127296-32767","2083454976-16383","2084569088-131071",
        "2085093376-524287","2086141952-524287","2087454720-2047","2087714816-524287","2088763392-524287","2090041344-32767",
        "2090598400-65535","2090860544-196607","2091646976-131071","2092957696-131071","2093219840-65535","2093481984-524287",
        "2094792704-327679","2095185920-524287","2096103424-32767","2096234496-65535","2096349184-16383","2096627712-32767",
        "2096693248-196607","2097020928-16383","2099232768-1064959","2100985856-32767","2101215232-16383","2101346304-2293759",
        "2103967744-1572863","2108358656-65535","2110783488-16383","2110914560-65535","2111111168-32767","2111242240-16383",
        "2111307776-524287","2113830912-16383","2260992000-65535","2482233344-8191","2682388480-65535","2714697728-65535",
        "2724790272-65535","2792292352-65535","2810904576-65535","2829058048-65535","3226696192-255","3229391360-255",
        "3233589760-255","3323004672-255","3389025792-255","3389165632-63","3389292544-8191","3389324288-1023","3389554688-8191",
        "3389669376-4095","3389937664-255","3389975296-1023","3390339072-255","3390502912-2047","3391488000-4095","3391504384-19199",
        "3391523840-1023","3391525376-511","3391526144-511","3391526912-1279","3391528960-511","3391529984-3583","3391535104-18431",
        "3391720960-255","3391723520-2047","3391746048-4095","3391852544-4095","3392020480-8191","3392069632-4095","3392958464-4095",
        "3393189888-1023","3393520640-1023","3393523712-4095","3393585152-8191","3393626112-4095","3393849344-2047","3393966080-4095",
        "3394087472-15","3394621440-4095","3394835712-255","3394895872-1023","3394953216-4095","3394960384-2047","3394994176-1023",
        "3395006464-4095","3395026944-1023","3395091456-2047","3395156992-9215","3395223552-8191","3395288064-1580255","3396868352-126719",
        "3397001216-2047","3397009408-8191","3397021696-2047","3397025792-255","3397083136-4095","3397234688-4095","3397320704-2047",
        "3397323776-5119","3397330944-6143","3397349376-14335","3397369856-4607","3397374976-11263","3397517312-8191","3397574656-8191",
        "3397586944-2047","3397595136-4095","3397636096-4095","3397922816-4095","3397963776-8191","3397975040-1023","3398279168-8191",
        "3398307840-4095","3398373376-4095","3398721536-8191","3398803456-8191","3398819840-8191","3398832128-4095","3399004160-4095",
        "3399036928-4095","3399393280-8191","3399528448-4095","3399745536-4095","3399864320-4095","3400048640-8191","3400171520-8191",
        "3400194048-2047","3400337408-2047","3400392704-8191","3400589312-8191","3400790016-4095","3400826880-8191","3400888320-4095",
        "3401404416-4095","3401580544-61951","3401642752-986367","3410952192-4095","3411054592-4095","3411087360-4095","3411228672-2047",
        "3411410944-24575","3411550208-8191","3411591168-8191","3411607552-1023","3411673088-1023","3411705856-24575","3411746816-8191",
        "3411763200-4095","3411769344-2047","3411804160-1023","3411845120-8191","3411869696-73727","3412000768-2047","3412025344-4095",
        "3412249888-15","3412250448-31","3412267008-4095","3412283392-4095","3412336640-4095","3412353024-8191","3412377600-4095",
        "3413024768-8191","3413557248-8191","3413579776-3071","3414171648-8191","3414188032-16383","3414302720-8191","3414433792-8191",
        "3414618112-2047","3414646784-8191","3414663168-4095","3415084032-511","3415474176-16383","3415752704-8191","3416047616-16383",
        "3416133632-2047","3416375296-8191","3416694784-8191","3417038848-4095","3417202688-8191","3417276416-8191","3417292800-16383",
        "3417853952-4095","3418071040-8191","3418251264-4095","3418296320-4095","3418308608-16383","3418329088-2047","3418357760-8191",
        "3418524575-31","3418619904-2047","3419357184-54271","3419414528-8191","3419529216-8191","3419668480-4095","3420334656-63",
        "3420366528-63","3420367776-15","3420369140-83","3420369344-63","3420370528-15","3420370576-15","3490863616-255","3523543040-8191",
        "3523575808-4095","3524001792-131071","3524149248-8191","3524165632-81919","3524296704-16383","3524591616-131071","3524853760-446979",
        "3525300744-1060343","3526557696-196607","3526934528-8191","3527933952-434175","3528409088-16383","3528450048-8191","3528589312-131071",
        "3528949760-16383","3535388672-16383","3535822848-8191","3537043456-4095","3544186880-524287","3545235456-1572863","3548905472-2097151",
        "3635658752-2047","3641206016-255","3656650624-63","3657433088-2097151","3661103104-2883583","3664248832-393215","3669606400-8191",
        "3670016000-1048575","3673161728-524287","3673751552-65535","3678928896-65535","3679584256-65535","3682598912-2097151","3688366080-1572863",
        "3690070016-393215","3697655808-16383","3698327552-262143","3701473280-3145727","3706126336-16383","3706159104-32767","3706208256-16383",
        "3706322944-65535","3707240448-327679","3707764736-835583","3708616704-196607","3715760128-131071","3716218880-196607","3716677632-131071",
        "3719036928-786431","3720347648-511999","3720871936-2621439","3725590528-5242879","3732733952-65535","3732930560-1048575","3735027712-262143",
        "3735552000-3670015","3740270592-655359");
	$i  = mt_rand(1,314);	
	$s  = $chinaip[$i];	
	$m  = strpos($s,"-");
	$s1 = substr($s,0,$m);	
	$s2 = substr($s,$m+1,strlen($s));	
	$i  = mt_rand(1,$s2);
	
	$s  = $s1 + $i;
	$s  = long2ip($s);
	return $s;
}

//...文本写入文件，返回写入的字节数 例：$filename= "./c/d/a.txt";
function txt_to_file($txt ,$filename)
{		
	$dir = dirname($filename);
	if (!file_exists($dir)) mkdir($dir,0777,true); 
	//chmod($dir,0777);
	return file_put_contents($filename , $txt );
}

//...文本写入文件,如果文件存在，添加在末尾，返回写入的字节数
function txt_to_file_ex($txt ,$filename)
{
	$dir = dirname($filename);
	if (!file_exists($dir)) mkdir($dir,0777,true); 
	//chmod($dir,0777);
	return file_put_contents($filename , $txt ,FILE_APPEND);
}

//...时间戳减8小时
function strtotime_8($time)
{
	return strtotime($time);
}

//...Html转文本函数
function htmlTotext($str,$encode = 'utf-8')
{    
	$str = preg_replace("/<style .*?<\/style>/is", "", $str);  
	$str = preg_replace("/<script .*?<\/script>/is", "", $str);  
	$str = preg_replace("/<br \s*\/?\/>/i", "\n", $str);  
	$str = preg_replace("/<\/?p>/i", "\n\n", $str);  
	$str = preg_replace("/<\/?td>/i", "\n", $str);  
	$str = preg_replace("/<\/?div>/i", "\n", $str);  
	$str = preg_replace("/<\/?blockquote>/i", "\n", $str);  
	$str = preg_replace("/<\/?li>/i", "\n", $str);  
	$str = preg_replace("/\&nbsp\;/i", " ", $str);  
	$str = preg_replace("/\&nbsp/i", " ", $str);    
	$str = preg_replace("/\&amp\;/i", "&", $str);  
	$str = preg_replace("/\&amp/i", "&", $str);    
	$str = preg_replace("/\&lt\;/i", "<", $str);  
	$str = preg_replace("/\&lt/i", "<", $str);    
	$str = preg_replace("/\&ldquo\;/i", '"', $str);  
	$str = preg_replace("/\&ldquo/i", '"', $str);      
	$str = preg_replace("/\&lsquo\;/i", "'", $str);      
	$str = preg_replace("/\&lsquo/i", "'", $str);      
	$str = preg_replace("/\&rsquo\;/i", "'", $str);      
	$str = preg_replace("/\&rsquo/i", "'", $str);  
	$str = preg_replace("/\&gt\;/i", ">", $str);   
	$str = preg_replace("/\&gt/i", ">", $str);   
	$str = preg_replace("/\&rdquo\;/i", '"', $str);   
	$str = preg_replace("/\&rdquo/i", '"', $str);   
	$str = strip_tags($str);  
	$str = html_entity_decode($str, ENT_QUOTES, $encode);  
	$str = preg_replace("/\&\#.*?\;/i", "", $str);          
	return $str;
}

//更新配置函数 /data/config.cache.inc.php
//结合 dede_sysconfig表，可以进行更改系统参数
function DeDe_ReWriteConfig($db_tablepre)
{		
	//配置文件
	$siteroot = str_ireplace('\\','/',dirname(__FILE__));
	$siteroot = dirname($siteroot).'/';
	$configfile = $siteroot.'/data/config.cache.inc.php';	
	
	if(!is_writeable($configfile))
	{
		echo "<___code___>999</___code___><desc>配置文件'{$configfile}'不支持写入，无法修改系统配置参数！</desc>";
		exit();
	}
	$fp = fopen($configfile,'w');
	flock($fp,3);
	fwrite($fp,"<"."?php\r\n");	
	$result = db_query("Select `varname`,`type`,`value`,`groupid` From `".$db_tablepre."sysconfig` order by aid asc ");
	while ($row = mysql_fetch_array( $result, MYSQL_ASSOC ))	
	{
		if($row['type']=='number')
		{
			if($row['value']=='') $row['value'] = 0;
			fwrite($fp,"\${$row['varname']} = ".$row['value'].";\r\n");
		}
		else
		{
			fwrite($fp,"\${$row['varname']} = '".str_replace("'",'',$row['value'])."';\r\n");
		}
	}
	fwrite($fp,"?".">");
	fclose($fp);
	
	echo "<___code___>0</___code___><desc>重写配置文件'{$configfile}'成功！</desc>";
}
//2016-07-14
	function curl_redir_exec($ch) 
	{ 
		static $curl_loops = 0; 
		static $curl_max_loops = 20; 

		if ($curl_loops++ >= $curl_max_loops) 
		{ 
			$curl_loops = 0; 
			return FALSE; 
		}
		
		curl_setopt($ch, CURLOPT_HEADER, true);
		
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
		$data = curl_exec($ch); 
		$debbbb = $data;
		$header='';
		if($data)
		{
			$arrData=explode("\n\n", $data, 2);
			if(count($arrData))
			{
				if(empty($arrData[1]))
				{
					$arrData[1]='';
				}
				list($header, $data) = $arrData;
			}
		}
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE); 

		if ($http_code == 301 || $http_code == 302) { 
			$matches = array(); 
			preg_match('/Location:(.*?)\n/', $header, $matches); 
			$url = @parse_url(trim(array_pop($matches))); 
			//print_r($url); 
			if (!$url) 
			{ 
				//couldn't process the url to redirect to 
				$curl_loops = 0;
				return $data; 
			} 
			$last_url = parse_url(curl_getinfo($ch, CURLINFO_EFFECTIVE_URL)); 
		/*    if (!$url['scheme']) 
				$url['scheme'] = $last_url['scheme']; 
			if (!$url['host']) 
				$url['host'] = $last_url['host']; 
			if (!$url['path']) 
				$url['path'] = $last_url['path'];*/ 
			$new_url = $url['scheme'] . '://' . $url['host'] . $url['path'] . ($url['query']?'?'.$url['query']:''); 
			curl_setopt($ch, CURLOPT_URL, $new_url); 
		//    debug('Redirecting to', $new_url); 

			return curl_redir_exec($ch); 
		} else { 
			$curl_loops=0;
			$arrData=explode("\n",$debbbb);
			$strData='';
			for($i=13;$i<count($arrData);$i++)
			{
				$strData.=$arrData[$i];
			}
			return $strData;
		} 
	}
//2016-07-14 下载文件
	function download_file($url = '', $filename = '')
	{

		//去除URL连接上面可能的引号
		//$url = preg_replace( '/(?:^['"]+|['"/]+$)/', '', $url );
		$hander = curl_init();
		if(!$url||!is_numeric(strpos($url,'http://'))||!$filename)
		{
			return 0;
		}
		if(file_exists($filename))
		{
			return 1;
		}
		$arrfile=explode('/',$filename);
		if(count($arrfile)>1)
		{
			$dir=dirname($filename);
			mkdir($dir,0700,true);
		}
		$fp = fopen($filename,'wb');
		curl_setopt($hander,CURLOPT_URL,$url);
		curl_setopt($hander,CURLOPT_FILE,$fp);
		curl_setopt($hander,CURLOPT_HEADER,0);
	//	curl_setopt($hander,CURLOPT_FOLLOWLOCATION,1);
	//	curl_setopt($hander,CURLOPT_RETURNTRANSFER,false);//以数据流的方式返回数据,当为false是直接显示出来
		curl_setopt($hander,CURLOPT_TIMEOUT,5);
	//	curl_exec($hander);
		curl_redir_exec($hander);
		curl_close($hander);
		fclose($fp);
		if(file_exists($filename))
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
//*********字符串函数***************************************************************
//一、验证码校验	
	//2011-01-17 18:23 hst 改进, 服务端调用无需验证
	if ($NoVerify!='TRUE')
	{
		if($verifycode!=trim($_REQUEST['verifycode']))
		{
			exit("<___code___>999</___code___><desc>错误的验证码</desc>");
		}
	}

//二、建立数据库连接（数据库连接不需要关闭，脚本执行完后会自动关闭）
	//db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);
	date_default_timezone_set("PRC");//设置时区
	
//三、基本的参数的获取
	//1、当前时间戳
	$timestamp  = time(); //当前时间戳
	$onlinetime = time(); //当前时间戳
	
	//2、随机数，供需要随即数的地方调用
	$m = mt_rand(1,50);  

	//3、当前随机Ip地址
	$onlineip = str_china_ip();


?>