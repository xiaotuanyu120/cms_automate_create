<?php
$NoVerify='TRUE';
//引入基本库文件
include_once('ccs_const.php');
include_once('ccs_config.php');
include_once('ccs_func.php');

db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);
db_query('set session sql_mode="NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"');

//================post信息========================
$username = trim($_POST['author']);
$fid 	  = trim($_POST['fid']);      //栏目
$tid 	  = trim($_POST['tid']);      //文章ID
$title    = trim($_POST['title']);    //标题
$content  = trim($_POST['content']);  //内容
//$time     = trim($_POST['time']);     //发布时间
$time     = date("Y-m-d H:i:s");    //如果想固定发帖时间为当前时间，请修改这里，取当前时间
$password = md5($password);
if(isset($_POST['files']))
{
	$files=stripslashes(trim($_POST['files']));
	$arrFiles=json_decode($files,1);
	if(!empty($arrFiles))
	{
		foreach($arrFiles as $v)
		{
			if(!empty($v['url'])&&!empty($v['savename']))
			{
				if(!download_file($v['url'],$v['savename']))
				{
					die('<___code___>999</___code___><desc>'.$v['url'].' 下载失败</desc>');
				}
			}
		}
	}
}

$username = substr($username,0,49); //...wordpress用户名称最长50位
if (empty($username)) $username = str_random(18);

$email    = str_random(20);
$email    = $email.'@21cn.com';

//发布时栏目ID不能为空
if (empty($fid))
{
	$message = '发布文章错误：栏目ID为空！';
	exit("<___code___>999</___code___><desc>$message</desc>");
}

//==============//发布操作=====================================
//一、判断用户是否存在, 不存在注册
$uid = db_first_value("SELECT id FROM {$db_tablepre}users WHERE user_login='$username' limit 1");

if (empty($uid))
{
	$sql = "insert into {$db_tablepre}users(user_login,user_pass,user_nicename,user_email,user_registered,display_name)   
			values('$username','$password','$username','$email','$time','$username')";
	$uid = db_insert_id($sql);
	if (empty($uid)) $uid = '0';
}

//二、主题发布，如果tid为空写文章，否则写评论
if (empty($tid))
{
	if (empty($title) || empty($content))
	{		
		exit("<___code___>999</___code___><desc>文章标题或内容为空</desc>");
	}	
	
	//1、写 wp_posts 表
	$sql = "insert into {$db_tablepre}posts(post_author,post_date,post_date_gmt,post_content,post_title,post_name,post_modified,post_modified_gmt) 
			values('$uid','$time','$time','$content','$title','$title','$datetime','$datetime')";
	$tid = db_insert_id($sql);
	
	//2、更新表wp_posts的guid字段
	$guid = 'http://'.$_SERVER['SERVER_NAME'].'/?p='.$tid;
	$sql = "update {$db_tablepre}posts set guid='$guid' where id='$tid'";
	db_query($sql);
	
	//3、写表 wp_term_relationships
	$sql = "insert into {$db_tablepre}term_relationships(object_id,term_taxonomy_id) values('$tid','$fid')";
	db_query($sql);
	
	//4、更新表 wp_term_taxonomy
	$sql = "update {$db_tablepre}term_taxonomy set count=count+1 where term_id='$tid'";
	db_query($sql);
	
	//5、写表 wp_postmeta
	//$sql = "insert into {$db_tablepre}postmeta";

	exit("<___code___>0</___code___><desc>$tid</desc>");
}
else
//三、回复信息
{
	//1、评论表 wp_comments
	$sql = "insert into {$db_tablepre}comments(comment_post_ID,comment_author,comment_author_email,comment_author_IP,comment_date,comment_date_gmt,comment_content,user_id) 
					values('$tid','$username','$email','$onlineip','$time','$time','$content','$uid')";
	$pid = db_insert_id($sql);	
	
	$sql = "update {$db_tablepre}posts set comment_count=comment_count+1 where id='$tid'";
	db_query($sql);

	echo "<___code___>0</___code___><desc>$pid</desc>";
}

?>