<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 6dcf44f32cf4bfcc950053e83df8b5db

$adminextend = array (
  0 => 'cloud.php',
);
?>