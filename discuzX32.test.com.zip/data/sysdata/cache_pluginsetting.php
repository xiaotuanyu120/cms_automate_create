<?php
//Discuz! cache file, DO NOT modify me!
//Identify: abdd6b5789652184db63a999d7d1e575

$pluginsetting = array (
);
?>