<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'DISCUZ_DBUSER');
define('UC_DBPW', 'DISCUZ_DBPASS');
define('UC_DBNAME', 'DISCUZ_DBNAME');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`DISCUZ_DBNAME`.discuzx32_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'XcQcb9x46791Y8Yd1edbY4N537v5I0h6U7jeV1I8j1ncv0c4ZcT6V0O7H8kcY273');
define('UC_API', 'http://DISCUZ_DOMAIN/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>
