<?php
header("Content-type:text/html;charset=utf-8"); 
error_reporting(E_ERROR | E_WARNING | E_PARSE);
//判断接口密钥待定

$root =  $_SERVER['DOCUMENT_ROOT'];
include($root."/config/config_global.php");
define('DB_HOST',$_config['db']['1']['dbhost']);
define('DB_USER',$_config['db']['1']['dbuser']);
define('DB_PASSWORD',$_config['db']['1']['dbpw']);
define('DB_NAME',$_config['db']['1']['dbname']);
define('DB_CHARSET',$_config['db']['1']['dbcharset']);

include("pinyin/ChinesePinyin.class.php");
$Pinyin = new ChinesePinyin();

/** 配置信息 **/
//网址
$domain = $_POST['domain'];
//网站名称
$sitename = $_POST['sitename'];		
//论坛首页title
$forumtitle = $_POST['title'];
//论坛首页keywords
$forumkeywords = $_POST['keywords'];	
//论坛首页description
$forumdescription = $_POST['description'];
//分类
$str = $_POST['column'];
$str = str_replace(array('\r','\\\\'),'',$str);
$cate = explode('\n',$str);
/** mysql帐号信息**/
$mysqli = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
if ($mysqli->connect_error) {
    die('Connect Error: ' . $mysqli->connect_error);
}else{
	$mysqli->set_charset(DB_CHARSET);
//	echo 'Success... ' . $mysqli->host_info . "\n";
}

/*
 ** 更新TDK
 **/
//全局-站点名称 (将显示在浏览器窗口标题等位置)
$sql = "update pre_common_setting set svalue = '$sitename' where skey = 'bbname'";
$mysqli->query($sql);
//全局-网站名称 (将显示在页面底部的联系方式处)
$sql = "update pre_common_setting set svalue = '$sitename' where skey = 'sitename'";
$mysqli->query($sql);
//全局-网站url
$sql = "update pre_common_setting set svalue = '$domain' where skey = 'siteurl'";
$mysqli->query($sql);

//全局-域名设置默认域名
$query = $mysqli->query("select svalue from pre_common_setting where skey='domain' limit 1");
$res = $query->fetch_array();
preg_match('/"default";(.+?);/',$res['svalue'],$match);
$old_domain = $match[1];
if(!empty($domain)){
	$titlelen = strlen($domain);
	$default_domain = 's:'.$titlelen.':"'.$domain.'"';
	$sql1 = "UPDATE pre_common_setting set svalue = REPLACE(svalue,'$old_domain','$default_domain') where skey='domain';";
	$mysqli->query($sql1);
}

//论坛首页title
$query = $mysqli->query("select svalue from pre_common_setting where skey='seotitle' limit 1");
$res = $query->fetch_array();
preg_match('/"forum";(.+?);/',$res['svalue'],$match);
$old_title = $match[1];
if(!empty($forumtitle)){
	$titlelen = strlen($forumtitle);
	$seotitle = 's:'.$titlelen.':"'.$forumtitle.'"';
	$sql1 = "UPDATE pre_common_setting set svalue = REPLACE(svalue,'$old_title','$seotitle') where skey='seotitle';";
	$mysqli->query($sql1);
}

//论坛首页keywords
$query = $mysqli->query("select svalue from pre_common_setting where skey='seokeywords' limit 1");
$res = $query->fetch_array();
preg_match('/"forum";(.+?);/',$res['svalue'],$match);
$old_keywords = $match[1];
if(!empty($forumkeywords)){
	$strlen = strlen($forumkeywords);
	$seokeywords = 's:'.$strlen.':"'.$forumkeywords.'"';
	$sql2 = "UPDATE pre_common_setting set svalue = REPLACE(svalue,'$old_keywords','$seokeywords') where skey='seokeywords';";
	$mysqli->query($sql2);
}

//论坛首页description
$query = $mysqli->query("select svalue from pre_common_setting where skey='seodescription' limit 1");
$res = $query->fetch_array();
preg_match('/"forum";(.+?);/',$res['svalue'],$match);
$old_description = $match[1];
if(!empty($forumdescription)){
	$strlen = strlen($forumdescription);
	$seodescription = 's:'.$strlen.':"'.$forumdescription.'"';
	$sql3 = "UPDATE pre_common_setting set svalue = REPLACE(svalue,'$old_description','$seodescription') where skey='seodescription';";
	$mysqli->query($sql3);
}

if(isset($_POST['column']) && $_POST['column'] !=''){
	/*
	 * 添加栏目
	 */
	 // 1. 添加新的分类
	 $sql4 = "insert into `pre_forum_forum` (fup,type,name,status) values(0,'group','$sitename',1);";
	 $mysqli->query($sql4);
	 $fub =$mysqli->insert_id;
	 echo '<br>添加新的分类'.$sitename.'<br>';
	 //添加新的版块
	 foreach($cate as $key=>$list){
		$sql = "insert `pre_forum_forum` (fup,type,name,status) values ($fub,'forum','".$list."',1);";
		$query = $mysqli->query($sql);
		$fid = $mysqli->insert_id;
		if($query) echo $list.'-->'.$fid.'添加成功<br>';
	}
}

$mysqli->close();