<?php
function getCurl($url)
{
	$header[] = 'Accept-Charset: utf-8';
	$ch = curl_init($url);  
	curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
	curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
			 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ; // 获取数据返回  
	curl_setopt($ch, CURLOPT_BINARYTRANSFER, true) ; // 在启用 CURLOPT_RETURNTRANSFER 时候将获取数据返回
	curl_setopt($ch,CURLOPT_REFERER,'http://www.so.com/');
	$output=curl_redir_exec($ch);//自动抓取302跳转
	//$output = curl_exec($ch) ;  
	return $output;
}

function curl_redir_exec($ch) 
{ 
    static $curl_loops = 0; 
    static $curl_max_loops = 20; 

    if ($curl_loops++ >= $curl_max_loops) 
    { 
        $curl_loops = 0; 
        return FALSE; 
    }
	
	curl_setopt($ch, CURLOPT_HEADER, true);
	
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
    $data = curl_exec($ch); 
    $debbbb = $data;
	$header='';
	if($data)
	{
		$arrData=explode("\n\n", $data, 2);
		if(count($arrData))
		{
			if(empty($arrData[1]))
			{
				$arrData[1]='';
			}
			list($header, $data) = $arrData;
		}
	}
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE); 

    if ($http_code == 301 || $http_code == 302) { 
        $matches = array(); 
        preg_match('/Location:(.*?)\n/', $header, $matches); 
        $url = @parse_url(trim(array_pop($matches))); 
        //print_r($url); 
        if (!$url) 
        { 
            //couldn't process the url to redirect to 
            $curl_loops = 0;
            return $data; 
        } 
        $last_url = parse_url(curl_getinfo($ch, CURLINFO_EFFECTIVE_URL)); 
    /*    if (!$url['scheme']) 
            $url['scheme'] = $last_url['scheme']; 
        if (!$url['host']) 
            $url['host'] = $last_url['host']; 
        if (!$url['path']) 
            $url['path'] = $last_url['path'];*/ 
        $new_url = $url['scheme'] . '://' . $url['host'] . $url['path'] . ($url['query']?'?'.$url['query']:''); 
        curl_setopt($ch, CURLOPT_URL, $new_url); 
    //    debug('Redirecting to', $new_url); 

        return curl_redir_exec($ch); 
    } else { 
        $curl_loops=0;
		$arrData=explode("\n",$debbbb);
		$strData='';
		for($i=13;$i<count($arrData);$i++)
        {
			$strData.=$arrData[$i];
		}
		return $strData;
    } 
} 
function get_file($url = '', $filename = '')
{

	//去除URL连接上面可能的引号
	//$url = preg_replace( '/(?:^['"]+|['"/]+$)/', '', $url );
	$hander = curl_init();
	if(!$url||!is_numeric(strpos($url,'http://'))||!$filename)
	{
		return 0;
	}
	if(file_exists($filename))
	{
		return 1;
	}
	$arrfile=explode('/',$filename);
	if(count($arrfile)>1)
	{
		$dir=dirname($filename);
		mkdir($dir,0700,true);
	}
	$fp = fopen($filename,'wb');
	curl_setopt($hander,CURLOPT_URL,$url);
	curl_setopt($hander,CURLOPT_FILE,$fp);
	curl_setopt($hander,CURLOPT_HEADER,0);
//	curl_setopt($hander,CURLOPT_FOLLOWLOCATION,1);
//	curl_setopt($hander,CURLOPT_RETURNTRANSFER,false);//以数据流的方式返回数据,当为false是直接显示出来
	curl_setopt($hander,CURLOPT_TIMEOUT,5);
//	curl_exec($hander);
	curl_redir_exec($hander);
	curl_close($hander);
	fclose($fp);
	if(file_exists($filename))
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
$isdownload=get_file('http://img.baidu.com/img/logo-80px.gif','abcd/wwdb/logo-80px.gif');
header('Content-type: text/html; charset=utf-8');
if($isdownload)
{
	echo '下载成功<br/>';
}
else
{
	echo '下载失败<br/>';
}
$files=array(array('url'=>'http://img.baidu.com/img/logo-80px.gif','savename'=>'abcd/wwdb/logo-80px.gif'),array('url'=>'http://img.baidu.com/img/logo-80px.gif','savename'=>'abcd/wwdb/logo-80px.gif'));
echo json_encode($files);
?>