<?php
$NoVerify='TRUE';
//引入基本库文件
include_once('ccs_const.php');
include_once('ccs_config.php');
include_once('ccs_func.php');

db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);
db_query('set session sql_mode="NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"');

//================post信息========================
$siteurl=		trim($_POST['domain']);
$sitename=		trim($_POST['sitename']);      //栏目
$title=			trim($_POST['title']);      //文章ID
$keywords=		trim($_POST['keywords']);    //标题
$description=	trim($_POST['description']);  //内容
$column=		trim($_POST['column']);
$str=			str_replace(array('\r','\\\\'),'',$column);
$cate=			explode("\n",$str);
$time=			date("Y-m-d H:i:s");    //如果想固定发帖时间为当前时间，请修改这里，取当前时间







if($title)
{
	/*修改多合一seo标题关键词描述*/
	$sql="select `option_value` from {$db_tablepre}options where `option_name`='aioseop_options'";
	$one=db_first_line($sql);
	$option_value=unserialize($one['option_value']);
	$option_value['aiosp_home_title']=$title;
	$option_value['aiosp_home_keywords']=$keywords;
	$option_value['aiosp_home_description']=$description;
	$one=serialize($option_value);
	$sql = "update {$db_tablepre}options set `option_value`='$one' where `option_name`='aioseop_options'";
	db_query($sql);

	
	//修改标题
	$sql = "update {$db_tablepre}options set `option_value`='$title' where `option_name`='blogname'";
	db_query($sql);
}


$sql = "update {$db_tablepre}options set `option_value`='' where `option_name`='blogdescription'";
db_query($sql);

//修改全局url
if($siteurl)
{
	if(!is_numeric(strpos($siteurl,'http://')))
	{
		$siteurl='http://'.$siteurl;
	}
	$sql = "update {$db_tablepre}options set `option_value`='$siteurl' where `option_name`='siteurl'";
	db_query($sql);
}
require_once('Utf8ToPy.class.php');
header('content-type:text/html;charset=utf-8');
if(count($cate)>0)
{
	foreach($cate as $cat)
	{
		$cat=trim($cat);
		$Utf8ToPy=new Utf8ToPy();
		$pinyin=$Utf8ToPy->encode($cat,'all');
		if($pinyin)
		{
			$sql="insert into {$db_tablepre}terms(name,slug,term_group) values('$cat','$pinyin','0')";
			$term_id = db_insert_id($sql);
			if($term_id)
			{
				$sql="insert into {$db_tablepre}term_taxonomy(term_id,taxonomy,description,parent) values('$term_id','category','','0')";
				$term_taxonomy_id = db_insert_id($sql);
				if($term_taxonomy_id) echo $cat.'-->'.$term_taxonomy_id.'添加成功<br>';
			}
		}
	}
}




?>