<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'DBNAME');

/** MySQL数据库用户名 */
define('DB_USER', 'DBUSER');

/** MySQL数据库密码 */
define('DB_PASSWORD', 'DBPASS');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'E_n4Ukfs|M-mOI(dspaJ4(rrxS3}u%HOuNJa-niC`cIVi#svpYO4feINh`&+Q~58');
define('SECURE_AUTH_KEY',  '75,1##iprB2O=k}l4+/(Q%KAd2pw|dDeZh_kl,)W.3Tsul-c$3iW|~>V*|NZl;=V');
define('LOGGED_IN_KEY',    'W%cj0qu8pn`w@y]z<8svcTI;O435XgyKDeDCP-$h(4vbLbo!]|Sl<+XX8ZKG5iqQ');
define('NONCE_KEY',        ' qA.-f-tq@}0 ...3a|Yk_tQdP1[X^+ywWWf&z`A]w}O>OICL?yv7$}o4`J:G,4l');
define('AUTH_SALT',        '{Y%VE&iv(b;j?|To`bzv7?N)KaGtu,{!0Vq*@_,j(%>CO(![ZzY4!Nf-*$zt5.:1');
define('SECURE_AUTH_SALT', 'GN1Nag[O*W;GP:Q@T|m(E2|XC}J?$7s-%)lyJ:G+h+z)-v-?OA-#LwC7E(f{FEQ$');
define('LOGGED_IN_SALT',   'gqN}uM5k&u:C+Je,Bc|tm U~_x~8X;lRbPZQn`], B1j-|xPv/3G-H,#7PgEkoA(');
define('NONCE_SALT',       'u^B/-kFdgGLvr<D{fP.^TkkJA5XJVO9~N74Cnn49A.L3gybRPZQns6*,x4]uk(Z&');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
