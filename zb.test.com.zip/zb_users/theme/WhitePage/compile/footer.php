		<div id="divBottom">
			<h4 id="BlogPowerBy">Powered By <?php  echo $zblogphphtml;  ?></h4>
			<h3 id="BlogCopyRight"><?php  echo $copyright;  ?></h3>
		</div><div class="clear"></div>
	</div><div class="clear"></div>
	</div><div class="clear"></div>
</div>
<?php  echo $footer;  ?>
</body>
</html>