<?php

//require_once "mysql.php";
error_reporting(E_ALL);
header("content-Type: text/html; charset=utf-8");
define('DB_HOST', 'localhost');
define('DB_USER', 'zb14');
define('DB_PASSWORD', '123456');
define('DB_NAME', 'zb14_ig_com');
define('DB_TABLEPRE', 'zb14');

?>
