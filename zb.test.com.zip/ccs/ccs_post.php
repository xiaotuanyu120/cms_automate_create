<?php
include_once('ccs_const.php');
include_once('ccs_func.php');
include_once('ccs_config.php');
$db_host = DB_HOST;
$db_name = DB_NAME;
$db_user = DB_USER;
$db_pwd  = DB_PASSWORD;
$dbtablepre = DB_TABLEPRE;
$db_charset = 'utf-8';

db_connect($db_host ,$db_name ,$db_user ,$db_pwd ,$db_charset);
db_query('set session sql_mode="NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"');
//$con = new mysqli($db_host,$db_user,$db_pwd,$db_name);
//$con ->mysqli_query("set names utf8");
//mysql_query($con,"set names gbk");
//mysql_query($con,'set session sql_mode="NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION"');

$tid      = trim($_POST['tid']);       //帖子id
$fid      = trim($_POST['fid']);       //分类id
$uid      = '';                 		//uid
$username = trim($_POST['username']);  //作者
$time     = time();      //添加时间
$title    = trim($_POST['title']);     //新闻标题
$content  = trim($_POST['content']);   //新闻内容

$username=empty($username)?'admin':$username;

$user = db_query("select mem_Id from {$dbtablepre}_member where mem_Name='".$username."'");//查询是否存在该作者
while($users = mysql_fetch_array($user)){
	
	
	$u[] = $users;
}

if(empty($u)){
	if(mysql_query("insert into {$dbtablepre}_member(mem_Name)  values ('$username')")){
		$addid = mysqli_insert_id($con);
	}else{
		exit('<code>901</code><desc>用户添加失败</desc>');
	}
}else{
	$addid = $u[0]['mem_Id'];
}
$description = mb_substr($content,0,20,'utf-8');
//echo "insert into {$dbtablepre}_post(log_AuthorID,log_Title,log_Intro,log_Content,log_PostTime)  values ('$addid','$title','$description','$content','$time')";
$a = mysql_query("insert into {$dbtablepre}_post(log_AuthorID,log_Title,log_Intro,log_Content,log_PostTime)
values ('$addid','$title','$description','$content','$time')");//添加文章
$pid = mysql_insert_id();
echo "<___code___>0</___code___><___desc___>id:$pid</___desc___>";exit;

?>